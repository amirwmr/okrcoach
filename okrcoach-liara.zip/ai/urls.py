from django.urls import path

from ai import views

urlpatterns = [
    path("", views.AnalysisCreateView.as_view(), name="ai-create"),
    path("<uuid:session_id>/", views.AnalysisDetailView.as_view(), name="ai-detail"),
]
